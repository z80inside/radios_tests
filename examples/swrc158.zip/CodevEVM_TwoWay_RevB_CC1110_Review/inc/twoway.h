
/*******************************************************************************************************
 * twoway.h                 For use with "CODEC EVM REV B" cards                                       *
 * Compiler:                IAR C Compiler for 8051                                                    *
 * Target platform:         Chipcon CC1110                                                             *
 * Author:                  TBR, KHO, ESY, MJB                                                         *
 * Last Update:             02 June 2009                                                               *                                                             
 ******************************************************************************************************/

#ifndef TWOWAY_H
#define TWOWAY_H

// Includes

#include "hal.h"
#include "iocc1110.h"

// Compile-time options

// Choose MASTER mode by uncommenting the line below
//#define MASTER        // Use this if compiling code for the Master (beacon)
#ifndef MASTER
#define SLAVE         // Default to Slave if Master is not defined
#endif

// data rate and modulation options
// Select (uncomment) only one!

#define BAUD250GFSK         // 250 kbps, GFSK modulation
//#define BAUD300MSK          // 300 kbps, MSK modulation

// PA and LNA options
// Caution: only one option may be selected!

// Three card options are supported for use at 900 MHz:
//
// Standard CC1110 EVM
// CC1110LNA for Codec (CC1110 plus Low Noise Amplifier - Rochester Design)
// CC1110PA for Codec (CC1110 plus Power Amplifier - Rochester Design)
// 
// They differ in how CC1110 ports P2_3 and P2_4 are used.
//
// The standard CC1110 EVM has P2_3 and P2_4 connected to a 32 kHz crystal, and are not available for use as DI or DO pins.
// The CC1110LNA card uses P2_4 for T/R control; set P2_4 low to receive and high to transmit. P2_3 is connected to socket pin 2, 
// but this pin is unconnected on the CODEC EVM card.
// The CC1110PA card uses P2_4 for T/R control; set P2_4 low to receive and high to transmit. P2_3 is connected to socket pin 2, 
// but this pin is unconnected on the CODEC EVM card.


//#define CC1110_PA_Rev_C           // This version uses P2_4 to enable the PA (high active)
#define CC1110_LNA_Rev_B          // This version uses P2_4 to enable the LNA (high active)
//#define CC1110_EVM                // P2_3 and P2_4 connect to a 32 kHz crystal

//-------------------------------------------------------------------------------------------------------
// Global definitions

#define MAC_ADDR_MASTER             0xC3    // The system's 1 byte MAC address (Master)
#define MAC_ADDR_SLAVE              0x3C    // The system's 1 byte MAC address (Slave)
#define RSSI_OFFSET                 77      // RSSI Offset (dB)
#define SYNCFND                     0x08    // SFD field of PKTSTATUS (Start of Frame Delimiter)

// Number of ADC samples per packet
#define AF_LEN  54

// Audio frame and buffer size
#define AF_BUF_SIZE  AF_LEN    // Size of audio buffer = number of ADC samples

// Packet format and segment lengths (bytes)
#define PHY_FIELD_LEN               1       // Length byte
#define MAC_FIELD_LEN               1       // MAC address
#define STATUS_FIELD_LEN            1       // Status bits
#define MAC_APPENDED_STATUS_LEN     2       // Status bytes added by PHY (CC2510)

#ifdef MASTER
#define TX_PAYLOAD_LEN  (MAC_FIELD_LEN + STATUS_FIELD_LEN + AF_LEN)
#define RX_PAYLOAD_LEN  (MAC_FIELD_LEN + STATUS_FIELD_LEN + AF_LEN)
#else
#define RX_PAYLOAD_LEN  (MAC_FIELD_LEN + STATUS_FIELD_LEN + AF_LEN)
#define TX_PAYLOAD_LEN  (MAC_FIELD_LEN + STATUS_FIELD_LEN + AF_LEN)
#endif

// RSSI level (Signal strength in dBm) below which the LNA will be enabled
// Note: RSSI is a negative value, but is converted to an absolute value when calculating the average.
// So a rssiavg value of 60 represents a signal level of -60 dBm
#define RSSI_ENABLE_LNA 60

// Define lost packet count threshold, above which the link is considered to be broken
#define LOST_PKTS_THR        4

// Frequency hopping
#define TOTAL_NUM_CHANNELS   4         // number of channels in the frequency hopping list

// DMA Channels
#define DMA_RX  1
#define DMA_TX  2
#define DMA_AUDIO_IN  3
#define DMA_AUDIO_OUT 4

// Timer flags
#define T3OVFIF                         0x01

// RX Off modes
#define RXOFFMODE_IDLE                  0x00
#define RXOFFMODE_FSTXON                0x04
#define RXOFFMODE_TX                    0x08
#define RXOFFMODE_RX                    0x0C

// Marcstates
#define MARCSTATE_IDLE                  0x01
#define MARCSTATE_RX                    0x0D
#define MARCSTATE_RX_OVERFLOW           0x11
#define MARCSTATE_TX                    0x13
#define MARCSTATE_TX_UNDERFLOW          0x16

// T2 (Frame timer) defines
// Note that T2 is a 'count down' timer; it starts at the vlaue set into T2CT and counts down to zero.
// T2 Tick period is 128 * T2PR clock cycles (128*6/26.0 = 29.538 usec)
// In Master mode, the frametimer is started (set to 'FRAME_TIMEOUT_DEFAULT') immediatly prior to sending a packet.
// In Slave mode, the frametimer is started (set to 'FRAME_TIMEOUT_DEFAULT') immediately after a packet is sucessfully received

// "FRAME_TIMEOUT_DEFAULT" is the time to collect ADC_SAMPLES samples at the ADC sample rate frequency, plus 250 usec
// "Frame_Time" = sample rate in msec * AF_LEN
//
// 8 kHz sample rate, 54 samples per packet: Frame_Time = .125 * 54 = 6.75 msec
// FRAME_TIMEOUT_DEFAULT = 6.75 + .250 = 7.000 msec 

// "LISTENFORMASTER" value calculation:
// Packet length (bytes) = AF_LEN + preamble bytes + sync bytes + CRC bytes + 3
// Packet length (usec) = packet length (bytes) * 8000 / data_rate in kbps
// Start Listening for Master packet length approximately packet length + 750 usec before the end of frame
//
// Examples:
//
// data rate = 250 kbaud, sample rate = 8 kHz: 
// packet length (bytes) = 54 + 4 + 4 + 2 + 3 = 67 bytes
// packet length (usec) = 67 * 8000 / 250 = 2144 usec
// LISTENFORMASTER = 2144 + 750 = 2894 usec (or 2894 / 29.538 = 98 Timer2 tics)
//
// data rate = 300 kbaud, sample rate = 8 kHz: 
// packet length (bytes) = 54 + 4 + 4 + 2 + 3 = 67 bytes
// packet length (usec) = 67 * 8000 / 300 = 1787 usec
// LISTENFORMASTER = 1787 + 750 = 2537 usec (or 2537 / 29.538 = 86 Timer2 tics)

#define FRAME_TIMEOUT_DEFAULT           237       // (T2CT) Timeout = 229 * 29.538 us = 7.000 msec
                                                  // Note that this is 250 usec longer than a frame, so T2 should never reach zero
#define END_OF_FRAME                      8       // T2CT count at end of frame (6.75 msec)

#ifdef BAUD250GFSK
#define LISTENFORMASTER                  98       // Start listening for master 2894 usec before the T2 times out
#define MASTER_RX_TIMEOUT                34       // Abort RX if GDO0 has not dropped 1004 usec before T2 times out
#endif

#ifdef BAUD300MSK
#define LISTENFORMASTER                  86       // Start listening for master 2537 usec before the T2 times out
#define MASTER_RX_TIMEOUT                34       // Abort RX if GDO0 has not dropped 1004 usec before T2 times out
#endif

// T3 Timeout defines (First parameter is timeout in 4.923076923 us, Second parameter is multiplier since this is a 8 bit timer only)
// For RX, the T3 timer sets the point (with reference to RX turn on) at which RX activity is checked. This is done by
// looking for high level on P1_5 (GDO0), which will be high from the time that SYNC is detected until the end of a packet.

// The value of "TX_TIMEOUT_WO_CALIB" is determined from packet length and data rate, as above
// Packet length (bytes) = AF_LEN + preamble bytes + sync bytes + CRC bytes + 3
// Packet length (usec) = packet length (bytes) * 8000 / data_rate in kbps
// Add approximately 250 usec to the value of 'packet length" 
//
// Examples:
//
// data rate = 250 kbaud, sample rate = 8 kHz: 
// packet length (bytes) = 54 + 4 + 4 + 2 + 3 = 67 bytes
// packet length (usec) = 67 * 8000 / 250 = 2144 usec
// TX_TIMEOUT_WO_CALIB = 2144 + 250 = 2394 usec 
//
// data rate = 300 kbaud, sample rate = 8 kHz: 
// packet length (bytes) = 54 + 4 + 4 + 2 + 3 = 67 bytes
// packet length (usec) = 67 * 8000 / 300 = 1787 usec
// TX_TIMEOUT_WO_CALIB = 1787 + 250 = 2037 usec 

#ifdef BAUD250GFSK
#define MASTER_TX_TIMEOUT_WO_CALIB      241, 2    // Timeout = 241 * 4.923076923 us * 2 = 2372.9 us
#define MASTER_RX_SYNC_TIMEOUT          163, 2    // Timeout = 163 * 4.923076923 us * 2 = 1604.9 us
#define SLAVE_TX_TIMEOUT_WO_CALIB       241, 2    // Timeout = 241 * 4.923076923 us * 2 = 2372.9 us
#define SLAVE_RX_SYNC_TIMEOUT           255, 1    // Timeout = 255 * 4.923076923 us * 1 = 1255.4 us
#endif

#ifdef BAUD300MSK
#define MASTER_TX_TIMEOUT_WO_CALIB      206, 2    // Timeout = 192 * 4.923076923 us * 2 = 2028.3 us
#define MASTER_RX_SYNC_TIMEOUT          255, 1    // Timeout = 255 * 4.923076923 us * 1 = 1255.4 us
#define SLAVE_TX_TIMEOUT_WO_CALIB       206, 2    // Timeout = 192 * 4.923076923 us * 2 = 2028.3 us
#define SLAVE_RX_SYNC_TIMEOUT           255, 1    // Timeout = 255 * 4.923076923 us * 1 = 1255.4 us
#endif

#define LISTEN_FOR_BEACON_TIMEOUT       229, 24   // Timeout = 229 * 4.923076923 us * 24 = 27.057 msec

// RX status flags
#define RX_IN_PROGRESS                  0x80
#define PACKET_RECEIVED                 0x40
#define RX_WAIT                         0x20
#define RX_COMPLETE                     0x10
#define RX_IDLE                         0x00

// RX packet/channel status
#define PKT_OK                          0x01
#define CRC_ERROR                       0x02
#define	TIMEOUT_ERROR                   0x04
#define PKT_ERROR                       0x08
#define DMA_ERROR                       0x10
#define PKT_STATUS_RESET                0x00

// Packet status values/bits
#define CRC_OK_MASK     0x80
#define CRC_LQI_VAL_IDX 1

// LED, Pushbutton Assignments

#define LED_BLUE_REG P1
#define LED_BLUE 0x01     // P1_0
#define LED_GREEN_REG P1
#define LED_GREEN  0x02   // P1_1
#define LED_YELLOW_REG P1
#define LED_YELLOW 0x04   // P1_2
#define LED_RED_REG P1
#define LED_RED 0x08      // P1_3

#define AGCSAMPLES 100      // AGC update rate = 12.5 msec

//----------------------------

#ifdef MASTER

// TX struct
typedef struct{
  BYTE macPayloadLen;                   // Length byte
  BYTE macField;                        // MAC address
  BYTE statusField;                     // Status Byte
  BYTE payload[AF_LEN];                 // Audio samples
} __xdata TX_MASTER_STRUCT;

// RX struct
typedef struct{
  BYTE macPayloadLen;                   // Length byte
  BYTE macField;                        // MAC address
  BYTE statusField;                     // Status byte
  BYTE payload[AF_LEN];                 // Audio samples
  BYTE append[MAC_APPENDED_STATUS_LEN]; // Status bytes (RSSI, LQI)
} __xdata RX_MASTER_STRUCT;

#endif

#ifdef SLAVE

// RX struct
typedef struct{
  BYTE macPayloadLen;                   // Length byte
  BYTE macField;                        // MAC address
  BYTE statusField;                     // Status Byte
  BYTE payload[AF_LEN];                 // Audio samples
  BYTE append[MAC_APPENDED_STATUS_LEN]; // Status bytes (RSSI, LQI)
} __xdata RX_SLAVE_STRUCT;

// TX struct
typedef struct{
  BYTE macPayloadLen;                   // Length byte
  BYTE macField;                        // MAC address
  BYTE statusField;                     // Status byte
  BYTE payload[AF_LEN];                 // Audio samples
} __xdata TX_SLAVE_STRUCT;

#endif

//-------------------------------------------------------------------------------------------------------
// Function prototype declarations

// init_peripherals.c
void init_peripherals(void);

// codec_TLV320AIC26.c
void initCodec(void);
void writeCodecRegister(BYTE pageaddress, BYTE address, INT16 data);

// tw_dma.c
void dmaAudio(void);
void dmaToRadio(WORD length, WORD srcAddr);
void dmaFromRadio(WORD length, WORD dstAddr);
void dmaMemtoMem(UINT8 length);

// tw_rf.c
BOOL initRf(void);
BOOL rfSendPacket(UINT8 timeout, UINT8 multiplier);
#ifdef MASTER
void rfReceivePacket(RX_MASTER_STRUCT __xdata * rxData, UINT8 synctimeout, UINT8 t3_multiplier, BYTE dmaNumber, UINT8 packetlen, UINT8 timeout);
#else
void rfReceivePacket(RX_SLAVE_STRUCT __xdata * rxData, UINT8 synctimeout, UINT8 t3_multiplier, BYTE dmaNumber, UINT8 packetlen, UINT8 timeout);
void ListenforMaster(RX_SLAVE_STRUCT __xdata * rxData, UINT8 timeout, UINT8 t3_multiplier, BYTE dmaNumber, UINT8 packetlen);
#endif

// tw_mac.c
void initFrameTimer(void);
void startFrameTimer(UINT8 cnt);
void macTimer3Init(void);
void macsetT3TimeoutAndWait(UINT8 timeout, UINT8 multiplier);
void setChannel (UINT8 ch);

//-------------------------------------------------------------------------------------------------------
// Global extern variables

#ifdef MASTER
extern TX_MASTER_STRUCT __xdata MAStxData;      // Data packet struct
extern RX_MASTER_STRUCT __xdata MASrxData;
#endif

#ifdef SLAVE
extern RX_SLAVE_STRUCT __xdata SLVrxData;       // Data packet struct
extern TX_SLAVE_STRUCT __xdata SLVtxData;
#endif

extern INT16 __xdata rssiavg;                   // allocated in tw_rf.c

// Status flags
extern volatile BYTE __xdata rxStatus;
extern volatile UINT8 __xdata rxPacketStatus;

extern UINT8 __xdata activeTable[TOTAL_NUM_CHANNELS];

extern BYTE __xdata audioIn[2][AF_BUF_SIZE];      // Audio In (microphone) Buffer
extern UINT8 __xdata activeIn;                    // Audio Input active buffer (0 | 1)
extern BYTE __xdata audioOut[2][AF_BUF_SIZE];     // Audio Out (playback) Buffer
extern UINT8 __xdata activeOut;                   // Audio Out active buffer (0 | 1)

// DMA
extern DMA_DESC __xdata DmaDesc0;
extern DMA_DESC __xdata DmaDesc1_4[];

extern UINT8 audioInindx;
extern UINT8 audioOutindx;
extern BOOL __xdata audioFrameReady;
extern UINT8 __xdata ActiveChIdx;
extern BOOL sfdDetected;
#endif

/***********************************************************************************
  Copyright 2009 Texas Instruments Incorporated. All rights reserved.

  IMPORTANT: Your use of this Software is limited to those specific rights
  granted under the terms of a software license agreement between the user
  who downloaded the software, his/her employer (which must be your employer)
  and Texas Instruments Incorporated (the "License").  You may not use this
  Software unless you agree to abide by the terms of the License. The License
  limits your use, and you acknowledge, that the Software may not be modified,
  copied or distributed unless embedded on a Texas Instruments microcontroller
  or used solely and exclusively in conjunction with a Texas Instruments radio
  frequency transceiver, which is integrated into your product.  Other than for
  the foregoing purpose, you may not use, reproduce, copy, prepare derivative
  works of, modify, distribute, perform, display or sell this Software and/or
  its documentation for any purpose.

  YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE
  PROVIDED �AS IS� WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
  INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE,
  NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL
  TEXAS INSTRUMENTS OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT,
  NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER
  LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
  INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE
  OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT
  OF SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
  (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

  Should you have any questions regarding your right to use this Software,
  contact Texas Instruments Incorporated at www.TI.com.
***********************************************************************************/

