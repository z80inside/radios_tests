/*
 *******************************************************************************************************
 * init_peripherals.c       For use with "CODEC EVM REV B" cards                                       *
 * Compiler:                IAR C Compiler for 8051                                                    *
 * Target platform:         Chipcon CC1110                                                             *
 * Author:                  MJB                                                                        *
 * Last Update:             01 June 2009                                                               *
 ******************************************************************************************************/

// Includes
#include "twoway.h"
#include "codec_TLV320AIC26.h"

////////////////////////////////////////////////////////////////////////////////
/// @brief	Initialize hardware peripherals, including P0, P1, P2,
///             Timers 1 and 4, and USART 0 (SPI)
///
////////////////////////////////////////////////////////////////////////////////

void init_peripherals(void) {

  // Port 0
  // P0_0  PIO xx   I2S LR CLK
  // P0_1  PIO xx   I2S BCLK 
  // P0_2  PIO xx   SPI MISO
  // P0_3  PIO xx   SPI MOSI
  // P0_4  I/O DO   SPI SS
  // P0_5  PIO xx   SPI SCLK
  // P0_6  I/O DI   JP1 pin 3 (SEL AUX IN) 
  // P0_7  I/O DI   JP1 pin 1 (ENA AGC)

  P0SEL = 0x2F;
  P0DIR |= 0x10;      
  P0 = 0x00;        

  // Port 1
  // P1_0  I/O DO   Blue LED (Heartbeat)
  // P1_1  I/O DO   Green LED (Paired)
  // P1_2  I/O DO   Yellow LED (Searching for Beacon)
  // P1_3  I/O DO   Red LED (Packet Lost)
  // P1_4  I/O DO   Reset Codec 
  // P1_5  PIO xx   GDO0 (JP5 pin 1)
  // P1_6  PIO xx   I2S DIN
  // P1_7  PIO xx   I2S DOUT

  P1SEL = 0xC0;
  P1DIR |= 0x1F;
  P1 = 0x10;              // The Codec Reset line is low active
  
  // Port 2
  // P2_0  PIO DO   I2S MCLK / T4CH0 
  // Note: Timer 4 I/O location must be set to 'Alternate 2'
  // P2_1  I/O DO   DD/Debug (JP3 pin 4)
  // P2_2  I/O DO   DC/Debug (JP3 pin 3)
  
#ifdef CC1110_EVM  
  // P2_3  UNAVAILABLE (XOSC)
  // P2_4  UNAVAILABLE (XOSC)

  P2SEL = 0x01;
  P2DIR = 0x07;         // Note: It is necessary to set PRIPO (bits 7:6) to b00 to insure that USART0 has control of pin P0_4 and PO_5       
  P2 = 0x00;
#else
  // P2_3  I/O DO   Unused       
  // P2_4  I/O DO   T/R
  
  P2SEL = 0x01;
  P2DIR = 0x1F;         // Note: It is necessary to set PRIPO (bits 7:6) to b00 to insure that USART0 has control of pin P0_4 and PO_5       
  P2 = 0x00;
#endif

  PERCFG = 0x10;        // Timer 4: Use Alternate 2 location (P2_0)
                        // USART0: Use Alternate 1 locations
                        // I2S: Use Alternate 1 locations
  
// I2S Setup  
  
  I2SCFG0 = 0x3E;     // Bit 7 - TX Interrupts disabled
                      // Bit 6 - RX Interrupts disabled
                      // Bit 5 - ulaw expansion enabled
                      // Bit 4 - ulaw compression enabled
                      // Bit 3 - TX mono mode enabled
                      // Bit 2 - RX mono mode enabled
                      // Bit 1 - mode set to Master
                      // Bit 0 - I2S interface disabled
  I2SCFG1 = 0x78;     // Bits 7:4 - WORDSIZE = 16 bits
                      // Bit 0 - IOLOC = 0 (Alternate 1)
  I2SCLKF2 = 0x06;    // Fsck = 256 kHz, Wordsize = 16 bits
  I2SCLKF1 = 0x59;    // Refer to Table 48 of CC2510 document
  I2SCLKF0 = 0x20;     
  
// Timer 1 Setup
//
// Timer 1 is used in modulo mode to generate an interrupt every 250 milliseconds

  // T1CTL.DIV (b3:2)  - 11b Prescaler divider set to 128 (clock frequency = 26/128 = 203.125 kHz)
  // T1CTL.MODE (B1:0) - 10b Modulo Mode
  T1CTL = 0x0E; 
  
  // T1CCTL0.IM   (b6) - 1b Enable interrupt request
  // T1CCTL0.MODE (b2) - 0b Capture Mode
  // T1CCTL0.CAP  (b1:0) - 00b No capture
  T1CCTL0 = 0x40;
  
  // Set Timer Terminal Count to 50781 (0xC65D)
  T1CC0L = 0x5D;
  T1CC0H = 0xC6;
  
// Timer 4 Setup
//
// Timer 4 is used to generate the CODEC MCLK (13 MHz) 
  
  T4CTL   = 0x06;     // Tick frequency/1, modulo mode; Clear the 'Start' bit
  T4CCTL0 = 0x14;     // Compare mode, toggle output on compare
  T4CC0   = 0x00;     // Set timeout period

// Set up USART0 in SPI mode. This connects to the TLV320AIC26 EVM. Refer to 'hal.h' for details
// Master mode, Clock idle level low, Clock phase latch data on falling clock edge, Transmit most significant bit first
  
  SPI_SETUP(0, 307200, SPI_MASTER | SPI_CLOCK_POL_LO | SPI_CLOCK_PHA_1 | SPI_TRANSFER_MSB_FIRST);    
  
  return;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief	Initialize timer3.
///
/// Initialize for use as RX timeout timer. 
/// 
////////////////////////////////////////////////////////////////////////////////

void macTimer3Init(void) {
  T3CCTL0 = 0;
  T3CCTL1 = 0;
  T3CTL = 0xE5;               // tick frequency = 128/26.000 = 4.923076923 usec
                              // interrupt on overflow disabled
                              // Clear the counter and set mode to Down (count from T3CCO to 0)  
}

/***********************************************************************************
  Copyright 2009 Texas Instruments Incorporated. All rights reserved.

  IMPORTANT: Your use of this Software is limited to those specific rights
  granted under the terms of a software license agreement between the user
  who downloaded the software, his/her employer (which must be your employer)
  and Texas Instruments Incorporated (the "License").  You may not use this
  Software unless you agree to abide by the terms of the License. The License
  limits your use, and you acknowledge, that the Software may not be modified,
  copied or distributed unless embedded on a Texas Instruments microcontroller
  or used solely and exclusively in conjunction with a Texas Instruments radio
  frequency transceiver, which is integrated into your product.  Other than for
  the foregoing purpose, you may not use, reproduce, copy, prepare derivative
  works of, modify, distribute, perform, display or sell this Software and/or
  its documentation for any purpose.

  YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE
  PROVIDED �AS IS� WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
  INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE,
  NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL
  TEXAS INSTRUMENTS OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT,
  NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER
  LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
  INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE
  OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT
  OF SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
  (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

  Should you have any questions regarding your right to use this Software,
  contact Texas Instruments Incorporated at www.TI.com.
***********************************************************************************/

