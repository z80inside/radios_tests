/*******************************************************************************************************
 * tw_dma.c                 DMA functions                                                              *
 * Compiler:                IAR C Compiler for 8051                                                    *
 * Target platform:         Chipcon CC1110                                                             *
 * Author:                  TBR, KHO, ESY, MJB                                                         *
 * Last Update:             02 June 2009                                                               *
 ******************************************************************************************************/

// Includes

#include "twoway.h"

//The following two #defines were lifted from "hal_CC2510.h' (Feb 2008)

#define DMATRIG_ADC_I2S_RX DMATRIG_ADC_CH6      // I2S word/byte received
#define DMATRIG_ADC_I2S_TX DMATRIG_ADC_CH7      // I2S word/byte transmitted

// Global variables

DMA_DESC __xdata DmaDesc0;
DMA_DESC __xdata DmaDesc1_4[4];
extern UINT8 __xdata frametime;

////////////////////////////////////////////////////////////////////////////////
/// @brief	Interrupt routine for DMA (Channels 3 and 4) generated interrupts.
///
////////////////////////////////////////////////////////////////////////////////

#pragma vector=DMA_VECTOR
__interrupt void dma_IRQ (void){
  INT_SETFLAG(INUM_DMA, INT_CLR);   // Clear the DMA IRQ flag

  if (DMAIRQ & DMA_CHANNEL_3) {     // DMA Channel 3 is used to transfer audio data from the audioIn buffer to the CODEC (I2STX)
    DMAIRQ = ~DMA_CHANNEL_3;        // While this may look like a mistake, it isn't!
                                    // The bits of DMAIRQ are R\W0 (Read or Write to zero only), so setting a bit to 1 via softeware is not possible
    frametime = T2CT;               // record the current frame timer count     
    activeIn ^= 0x01;               // Switch Buffers
    if (activeIn == 0) {
      SET_WORD(DmaDesc1_4[2].SRCADDRH, DmaDesc1_4[2].SRCADDRL, audioIn[1]);
    }
    else {
      SET_WORD(DmaDesc1_4[2].SRCADDRH, DmaDesc1_4[2].SRCADDRL, audioIn[0]);
    }
    DMA_ARM_CHANNEL(3);
  }

  if (DMAIRQ & DMA_CHANNEL_4) {     // DMA Channel 4 is used to transfer audio data from the CODEC (I2SRX) to the audioOut buffer
    DMAIRQ = ~DMA_CHANNEL_4;        // While this may look like a mistake, it isn't!
                                    // The bits of DMAIRQ are R\W0 (Read or Write to zero only), so setting a bit to 1 via softeware is not possible
    activeOut ^= 0x01;              // Switch Buffers
    if (activeOut == 0)
      SET_WORD(DmaDesc1_4[3].DESTADDRH, DmaDesc1_4[3].DESTADDRL, audioOut[1]);
    else 
      SET_WORD(DmaDesc1_4[3].DESTADDRH, DmaDesc1_4[3].DESTADDRL, audioOut[0]);
    audioFrameReady = TRUE;
    DMA_ARM_CHANNEL(4);
  }

  INT_GLOBAL_ENABLE(INT_ON);        // Re-enable interrupts
}

////////////////////////////////////////////////////////////////////////////////
/// @brief	This function configures DMA transfer from the radio to an RX buffer.
///
/// The first byte of the data to be transferred contains the number of bytes
/// to be transferred (variable packet length). When done, the DMA channel may
/// generate an interrupt.
///
/// @param[in]  dstAddr
///             The start address in __xdata space to where the data is to be stored
///
/// Uses DMA Channel 1
///
////////////////////////////////////////////////////////////////////////////////

void dmaFromRadio(WORD length, WORD dstAddr){
  SET_WORD(DmaDesc1_4[0].SRCADDRH, DmaDesc1_4[0].SRCADDRL, &X_RFD);     // Set RFD register as source
  SET_WORD(DmaDesc1_4[0].DESTADDRH, DmaDesc1_4[0].DESTADDRL, dstAddr);  // RX buffer address
  SET_WORD(DmaDesc1_4[0].LENH, DmaDesc1_4[0].LENL, length);             // Set the length of the transfer (bytes)
  DmaDesc1_4[0].VLEN       = VLEN_USE_LEN;                              // Use the length field
  DmaDesc1_4[0].PRIORITY   = PRI_LOW;
  DmaDesc1_4[0].M8         = M8_USE_8_BITS;
  DmaDesc1_4[0].IRQMASK    = IRQMASK_DISABLE;     // No interrupt on DMA completion.
  DmaDesc1_4[0].DESTINC    = DESTINC_1;           // The destination is constant
  DmaDesc1_4[0].SRCINC     = SRCINC_0;            // The source address increments by 1 byte for each transfer.
  DmaDesc1_4[0].TRIG       = DMATRIG_RADIO;       // DMA is started by the radio receiver.
  DmaDesc1_4[0].TMODE      = TMODE_SINGLE;        // One byte is transferred at each DMA trigger.
  DmaDesc1_4[0].WORDSIZE   = WORDSIZE_BYTE;       // Byte transfer.

  return;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief	This function configures DMA transfer to the radio from a TX buffer.
///
///
/// @param[in]  length
///             The length (bytes) of packet to move from TX buffer
///
/// @param[in]  srcAddr
///             The start address in __xdata space into which the data to be transferred.
///
/// Uses DMA Channel 2
///
////////////////////////////////////////////////////////////////////////////////

void dmaToRadio(WORD length, WORD srcAddr){
   SET_WORD(DmaDesc1_4[1].SRCADDRH, DmaDesc1_4[1].SRCADDRL, srcAddr);   // TX buffer address
   SET_WORD(DmaDesc1_4[1].DESTADDRH, DmaDesc1_4[1].DESTADDRL, &X_RFD);  // Set RFD register as destination
   SET_WORD(DmaDesc1_4[1].LENH, DmaDesc1_4[1].LENL, length);            // Set the length of the transfer (bytes)
   DmaDesc1_4[1].VLEN      = VLEN_USE_LEN;                              // Use the length field
   DmaDesc1_4[1].PRIORITY  = PRI_LOW;
   DmaDesc1_4[1].M8        = M8_USE_8_BITS;       // Transferring all 8 bits in each byte.
   DmaDesc1_4[1].IRQMASK   = IRQMASK_DISABLE;     // No interrupt on DMA completion.
   DmaDesc1_4[1].DESTINC   = DESTINC_0;           // The destination address is constant
   DmaDesc1_4[1].SRCINC    = SRCINC_1;            // The address for data fetch is inremented by 1 byte
                                                  // after each transfer.
   DmaDesc1_4[1].TRIG      = DMATRIG_RADIO;       // DMA is started by writing the radio
   DmaDesc1_4[1].TMODE     = TMODE_SINGLE;        // Byte for byte is transferred.
   DmaDesc1_4[1].WORDSIZE  = WORDSIZE_BYTE;       // One byte is transferred each time.

   return;
}

////////////////////////////////////////////////////////////////////////////////
/// This function configures DMA transfer from the AudioOut buffer to the CODEC (DMA Channel 3)
/// And from the DODEC to the AudioIn buffer (DMA Channel 4)
////////////////////////////////////////////////////////////////////////////////

void dmaAudio(void){
// Setup DMA descriptor for Audio to CODEC using DMA Channel 3
// Audio going to the CODEC comes from the AudioIn buffer  

  SET_WORD(DmaDesc1_4[2].SRCADDRH, DmaDesc1_4[2].SRCADDRL, audioIn[0]);
  SET_WORD(DmaDesc1_4[2].DESTADDRH, DmaDesc1_4[2].DESTADDRL, &I2SDATH);
  DmaDesc1_4[2].VLEN       = VLEN_FIXED;
  DmaDesc1_4[2].LENH       = 0;
  DmaDesc1_4[2].LENL       = AF_BUF_SIZE;
  DmaDesc1_4[2].WORDSIZE   = WORDSIZE_BYTE;
  DmaDesc1_4[2].TMODE      = TMODE_SINGLE;
  DmaDesc1_4[2].TRIG       = DMATRIG_ADC_I2S_TX;  
  DmaDesc1_4[2].SRCINC     = SRCINC_1;
  DmaDesc1_4[2].DESTINC    = DESTINC_0;
  DmaDesc1_4[2].IRQMASK    = IRQMASK_ENABLE;
  DmaDesc1_4[2].M8         = M8_USE_8_BITS;
  DmaDesc1_4[2].PRIORITY   = PRI_LOW;
  
// Setup DMA descriptor for Audio from CODEC using DMA Channel 4
// Audio from the CODEC goes into the 'audioOut' buffer to be transmitted
  
  SET_WORD(DmaDesc1_4[3].SRCADDRH, DmaDesc1_4[3].SRCADDRL, &I2SDATH);
  SET_WORD(DmaDesc1_4[3].DESTADDRH, DmaDesc1_4[3].DESTADDRL, audioOut[0]);
  DmaDesc1_4[3].VLEN       = VLEN_FIXED;
  DmaDesc1_4[3].LENH       = 0;
  DmaDesc1_4[3].LENL       = AF_BUF_SIZE;
  DmaDesc1_4[3].WORDSIZE   = WORDSIZE_BYTE;  
  DmaDesc1_4[3].TMODE      = TMODE_SINGLE;
  DmaDesc1_4[3].TRIG       = DMATRIG_ADC_I2S_RX;  
  DmaDesc1_4[3].SRCINC     = SRCINC_0;
  DmaDesc1_4[3].DESTINC    = DESTINC_1;
  DmaDesc1_4[3].IRQMASK    = IRQMASK_ENABLE;
  DmaDesc1_4[3].M8         = M8_USE_8_BITS;
  DmaDesc1_4[3].PRIORITY   = PRI_LOW;

  return;
}

///////////////////////////////////////////////////////////////////////////////
/// @brief	This function configures DMA transfer a block of data
///             from 'srcAddr' to 'dstAddr'
///
/// @param[in]  length - the number of words to be transferred
///
/// Uses DMA Channel 0
///
////////////////////////////////////////////////////////////////////////////////

void dmaMemtoMem(UINT8 length){
  
  DmaDesc0.VLEN       = VLEN_FIXED;
  DmaDesc0.LENH       = 0;
  DmaDesc0.LENL       = length;
  DmaDesc0.WORDSIZE   = WORDSIZE_BYTE;
  DmaDesc0.TMODE      = TMODE_BLOCK;
  DmaDesc0.TRIG       = DMATRIG_NONE;       // Triggered by setting DMAREQ
  DmaDesc0.DESTINC    = DESTINC_1;          // Increment destination address
  DmaDesc0.IRQMASK    = IRQMASK_DISABLE;
  DmaDesc0.M8         = M8_USE_8_BITS;
  DmaDesc0.PRIORITY   = PRI_LOW;
  
  return;
}

/***********************************************************************************
  Copyright 2009 Texas Instruments Incorporated. All rights reserved.

  IMPORTANT: Your use of this Software is limited to those specific rights
  granted under the terms of a software license agreement between the user
  who downloaded the software, his/her employer (which must be your employer)
  and Texas Instruments Incorporated (the "License").  You may not use this
  Software unless you agree to abide by the terms of the License. The License
  limits your use, and you acknowledge, that the Software may not be modified,
  copied or distributed unless embedded on a Texas Instruments microcontroller
  or used solely and exclusively in conjunction with a Texas Instruments radio
  frequency transceiver, which is integrated into your product.  Other than for
  the foregoing purpose, you may not use, reproduce, copy, prepare derivative
  works of, modify, distribute, perform, display or sell this Software and/or
  its documentation for any purpose.

  YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE
  PROVIDED �AS IS� WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
  INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE,
  NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL
  TEXAS INSTRUMENTS OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT,
  NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER
  LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
  INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE
  OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT
  OF SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
  (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

  Should you have any questions regarding your right to use this Software,
  contact Texas Instruments Incorporated at www.TI.com.
***********************************************************************************/




