/*
 *******************************************************************************************************
 * tw_main.c                For use with "CODEC EVM REV B" cards                                       *
 * Compiler:                IAR C Compiler for 8051                                                    *
 * Target platform:         Chipcon CC1110                                                             *
 * Author:                  MJB                                                                        *
 * Last Update:             27 May 2009                                                                *
 ******************************************************************************************************/

// Includes
#include "twoway.h"
#include "codec_TLV320AIC26.h"

// Global variables
volatile BYTE __xdata rxStatus = 0;
UINT16 __xdata adcgainctrl;

// External variables

extern const UINT8 HoppingChannels[TOTAL_NUM_CHANNELS];

UINT8 __xdata activeIn = 0;               // Audio In (to Codec) active buffer (0 | 1)
BYTE  __xdata audioIn[2][AF_BUF_SIZE];    // Audio In (to Codec) data buffer
UINT8 __xdata activeOut = 0;              // Audio Out (from Codec) active buffer (0 | 1)
BYTE  __xdata audioOut[2][AF_BUF_SIZE];   // Audio Out (from Codec) data buffer

// Note: The concept of 'In' and 'Out' is rather confusing, as is the concept of 'RX' and 'TX'. Here, 'RX' and 'TX"
// refer to the RF transceiver, NOT to the I2S RX and TX functions.
//
// The AudioIn buffer conatins audio samples to be sent to the Codec that were received (RX) from the Slave (if Master) or from the Master (if Slave).
// The ActiveOut buffer conatins audio samples obtained from the Codec that will be sent (TX) to the Slave (if Master) or to the Master (if Slave). 

BOOL   waitingforbeacon = TRUE;
UINT8  i, j;
UINT8  lostpkts = 0;
UINT8  optionstatus = 0xC0;           // The option bits (P0_6 and P0_7) are 'pulled high' by default (i.e., low true)
UINT8  __xdata audionull = 0xC7;      // I2S data for muted audio

UINT8 __xdata frametime;              // T2 (frametimer) count when DMA switches from using buffer B to using Buffer A

// Frequency hopping sequence

const UINT8 HoppingChannels[TOTAL_NUM_CHANNELS] = {0, 8, 24, 32};

// Channel 0: 914.000 MHz
// Chaneel 8: 916.000 MHz
// Channel 24: 920.000 MHz
// Channel 32:  922.000 MHz

UINT8 __xdata ActiveChIdx;

////////////////////////////////////////////////////////////////////////////////
/// @brief	Application main function.
////////////////////////////////////////////////////////////////////////////////
void main(void) {

  // Initializations
  SET_MAIN_CLOCK_SOURCE(CRYSTAL);
  SET_MAIN_CLOCK_SPEED(MHZ_26);
  CLKCON = (CLKCON & 0xC7);

  init_peripherals();                     // Initilize ports (P0, P1, P2), Timers 1 and 4, I2S, SPI (USART0) 
  initCodec();                            // Initilize the Codec
                                          // Sample Rate = 8 kHz, word length = 16 bits, mode = mono
  
  INT_SETFLAG(INUM_DMA, INT_CLR);         // clear the DMA interrupt flag
  I2SCFG0 |= 0x01;                        // Enable the I2S interface 

  DMA_SET_ADDR_DESC0(&DmaDesc0);          // Set up DMA configuration table for channel 0
  DMA_SET_ADDR_DESC1234(&DmaDesc1_4[0]);  // Set up DMA configuration table for channels 1 - 4
  
  dmaMemtoMem(AF_BUF_SIZE);               // Set up DMA Channel 0 for memmory to memory data transfers
  initRf();                               // Set radio base frequency and reserve DMA channels 1 and 2 for RX/TX buffers
  dmaAudio();                             // Set up DMA channels 3 and 4 for the Audio In/Out buffers
  DMAIRQ = 0;
  DMA_ARM_CHANNEL(3);                     // Arm DMA channels 2 and 3 (CODEC)
  DMA_ARM_CHANNEL(4);
   
  macTimer3Init();

  INT_ENABLE(INUM_T1, INT_ON);            // Enable Timer 1 interrupts
  INT_ENABLE(INUM_DMA, INT_ON);           // Enable DMA interrupts
  INT_GLOBAL_ENABLE(INT_ON);              // Enable Global interrupts
    
#ifdef MASTER

// Master Code

  MAStxData.macPayloadLen = TX_PAYLOAD_LEN;
  MAStxData.macField = MAC_ADDR_MASTER;
  MAStxData.statusField = 0x00;
 
  while (1)  {        // main program loop
    setChannel(HoppingChannels[ActiveChIdx]);   // SetChannel will set the MARCSTATE to IDLE
    ActiveChIdx++;
    if (ActiveChIdx == TOTAL_NUM_CHANNELS)
      ActiveChIdx = 0;

    SCAL();                                     // Start PLL calibration at new channel
   
#ifdef CC1110_LNA_Rev_B
    P2 &= ~0x10;                                // clear P2_4 (Disable LNA)
#endif    
#ifdef CC1110_PA_Rev_C
    P2 |= 0x10;                                 // set P2_4 (Enable PA)
#endif    
    
    if ((P0 & 0x40) != optionstatus) {                  // if the 'SEL AUX IN' option bit has changed state
      if ((P0 & 0x40) == 0) {                           // SEL AUX IN has changed state to true
        writeCodecRegister(AUDIO_CONTROL_1, 0x103F);    // CODEC ADC Input: 'Single-ended AUX'
        adcgainctrl &= 0x0001;                          // Set ADC gain to 0 dB
        writeCodecRegister(ADC_GAIN_CONTROL, adcgainctrl);      
        optionstatus &= ~0x40;
      }
      else {                                            // SEL AUX IN has changed state to false
        writeCodecRegister(AUDIO_CONTROL_1, 0x003F);    // CODEC ADC Input: 'Single-ended MICIN'
        adcgainctrl |= 0x3400;                          // Set ADC gain to 26 dB
        writeCodecRegister(ADC_GAIN_CONTROL, adcgainctrl);      
        optionstatus |= 0x40;
      }
    }
     
    if ((P0 & 0x80) != optionstatus) {          // if the 'ENA AGC' option bit has changed state
      if ((P0 & 0x80) == 0) {                   // ENA AGC has changed state to true
        adcgainctrl |= 0x0001;                  // Enable the AGC
        writeCodecRegister(ADC_GAIN_CONTROL, adcgainctrl);      
        optionstatus &= ~0x80;
      }
      else {                                    // SEL AUX IN has changed state to false
        adcgainctrl &= ~0x0001;                 // Disable the AGC
        writeCodecRegister(ADC_GAIN_CONTROL, adcgainctrl);      
        optionstatus |= 0x80;
      }    
    }
    
// Now wait for an audio frame signal     
    
    while (audioFrameReady == FALSE);     // Wait until an audioframe is ready to be transmitted

    audioFrameReady = FALSE;              // Reset the flag
    
// Move data from the CODEC (audioOut) buffer to the TX buffer
// Note: this awkward looking code results in faster execution than the more obvious code used elsewhere    
    
    for (j = 0; j < AF_BUF_SIZE; j++) {
      if (activeOut == 0)
        MAStxData.payload[j] = audioOut[0][j];
      else 
        MAStxData.payload[j] = audioOut[1][j];
    }

    while (MARCSTATE != 0x01);            // Wait for calibration to complete

    T2CT = FRAME_TIMEOUT_DEFAULT;         // Reset the Frame Timer just prior to enabling the TX
 
    rfSendPacket(MASTER_TX_TIMEOUT_WO_CALIB);

// At this point the LNA (if present) is dissabled 
    
#ifdef CC1110_LNA_Rev_B
    if (rssiavg > RSSI_ENABLE_LNA)       // if RSSI (signal strength) is too low ...
      P2 |= 0x10;                        // set P2_4 (Enable LNA)
#endif
#ifdef CC1110_PA_Rev_C
    P2 &= ~0x10;                         // clear P2_4 (Disable PA)
#endif   

// Listen for data from Slave

    rfReceivePacket(&MASrxData, MASTER_RX_SYNC_TIMEOUT, DMA_RX, RX_PAYLOAD_LEN, MASTER_RX_TIMEOUT);

    if (rxPacketStatus == TIMEOUT_ERROR) {
      LED_RED_REG |= LED_RED;       // Lite the Red LED

// Fill the audioIn buffer with 'zeros'      
      
      for (i = 0; i < AF_BUF_SIZE; i++) {   // this code style results in faster execution
        if (activeIn == 0)
          audioIn[0][i] = 0xCE;
        else
          audioIn[1][i] = 0xCE;
      }
    }
    else {                                  // A packet was received
      LED_RED_REG &= ~LED_RED;              // Extingusih the Red LED
     
      if (rxPacketStatus == PKT_OK) {
        for (i = 0; i < AF_BUF_SIZE; i++) {   // Move data from rxbuffer to audioIn buffer
          if (activeIn == 0)  
            audioIn[0][i] = MASrxData.payload[i];
          else
            audioIn[1][i] = MASrxData.payload[i];   
        }
      }
      else {
        for (i = 0; i < AF_BUF_SIZE; i++) {   // mute audio for the duration of the packet
          if (activeIn == 0)                  // this code style results in faster execution
            audioIn[0][i] = 0xCE;
          else
            audioIn[1][i] = 0xCE;;
        }
      }
    }     // end of TIMEOUT_ERROR 'else' (i.e., packet received)
  }   // end of 'while (1)' loop

#else

// Slave Code

// Initilize Timer 2 (Frame Timer)

  T2CT = 0;         // Stop the timer
  T2PR = 6;         // Timer Prescale Multipler
  T2CTL = 0x01;     // Set Tick period to 128 * T2PR clock cycles (128*6/26.0 = 29.538 usec)
                    // Interrupts Disabled

  SLVtxData.macPayloadLen = TX_PAYLOAD_LEN;
  SLVtxData.macField = MAC_ADDR_SLAVE;

#ifdef CC1110_LNA_Rev_B
    P2 |= 0x10;                             // set P2_4 (Enable LNA)
#endif
#ifdef CC1110_PA_Rev_C
    P2 &= ~0x10;                            // clear P2_4 (Disable PA)
#endif   
  
  while (1)  {                              // main program loop
    if (waitingforbeacon) {
      LED_GREEN_REG &= ~LED_GREEN;          // Extinguish the Green (paired) LED
      LED_YELLOW_REG |= LED_YELLOW;         // Light the Yellow LED (Waiting for Beacon)
      setChannel(HoppingChannels[0]);       // Listen on channel[0] for the beacon
      SCAL();                               // Start PLL calibration at new channel
      while (MARCSTATE != MARCSTATE_IDLE);  // Wait for calibration to complete

      while (1) {                           // Stay in this loop until the Beacon is heard
#ifdef CC1110_LNA_Rev_B                     // First, use the LNA
        P2 |= 0x10;                         // set P2_4 (Enable LNA)
#endif
        ListenforMaster(&SLVrxData, LISTEN_FOR_BEACON_TIMEOUT, DMA_RX, RX_PAYLOAD_LEN);
        if (rxPacketStatus == PKT_OK)
          break;
#ifdef CC1110_LNA_Rev_B                     // Try again with the LNA disabled
        P2 &= ~0x10;                        // clear P2_4 (Enable LNA)
        ListenforMaster(&SLVrxData, LISTEN_FOR_BEACON_TIMEOUT, DMA_RX, RX_PAYLOAD_LEN);
        if (rxPacketStatus == PKT_OK)
          break;
#endif        
      }   // end of 'while (1)' loop

      LED_YELLOW_REG &= ~LED_YELLOW;        // Extinguish the Yellow LED (Waiting for Beacon)
      LED_GREEN_REG |= LED_GREEN;           // Light the Green ('Paired') LED
      lostpkts = 0;
      ActiveChIdx = 1;                      // set up next channel
      waitingforbeacon = FALSE;             // Exit 'waitingforbeacon' mode
      T2CT = FRAME_TIMEOUT_DEFAULT;         // Reset the Frame Timer
    }     // end of 'waitingforbeacon' if

    else {                                // We are 'Paired'

// Check the status of the 'option' jumpers
      
       if ((P0 & 0x40) != optionstatus) {                   // if the 'SEL AUX IN' option bit has changed state
        if ((P0 & 0x40) == 0) {                             // SEL AUX IN has changed state to true
          writeCodecRegister(AUDIO_CONTROL_1, 0x103F);      // CODEC ADC Input: 'Single-ended AUX'
          adcgainctrl &= 0x0001;                            // Set ADC gain to 0 dB
          writeCodecRegister(ADC_GAIN_CONTROL, adcgainctrl);      
          optionstatus &= ~0x40;
        }
        else {                                              // SEL AUX IN has changed state to false
          writeCodecRegister(AUDIO_CONTROL_1, 0x003F);      // CODEC ADC Input: 'Single-ended MICIN'
          adcgainctrl |= 0x3400;                            // Set ADC gain to 26 dB
          writeCodecRegister(ADC_GAIN_CONTROL, adcgainctrl);      
          optionstatus |= 0x40;
        }
      }
     
      if ((P0 & 0x80) != optionstatus) {          // if the 'ENA AGC' option bit has changed state
        if ((P0 & 0x80) == 0) {                   // ENA AGC has changed state to true
          adcgainctrl |= 0x0001;                  // Enable the AGC
          writeCodecRegister(ADC_GAIN_CONTROL, adcgainctrl);      
          optionstatus &= ~0x80;
        }
        else {                                    // SEL AUX IN has changed state to false
          adcgainctrl &= ~0x0001;                 // Disable the AGC
          writeCodecRegister(ADC_GAIN_CONTROL, adcgainctrl);      
          optionstatus |= 0x80;
        }    
      }
      
// Listen for packet from Master

      if ((frametime > 0x80) && (frametime < 0x9C))     // if in the so called 'bad zone' ...
        I2SCLKF1 = 0x57;                                // speed up the I2S bit clock
        
      if ((frametime > 0x10) && (frametime < 0x5F))     // if in the so called 'good zone' ...
        I2SCLKF1 = 0x59;                                // reset the bit clock frequency to 256 kbps
   
      while (MARCSTATE != MARCSTATE_IDLE);      // Wait for calibration to complete (Machine State = Idle)

      while (T2CT > LISTENFORMASTER);           // Wait until it's time to listen for the Master

      rfReceivePacket(&SLVrxData, SLAVE_RX_SYNC_TIMEOUT, DMA_RX, RX_PAYLOAD_LEN, 0);
 
      if (rxPacketStatus == TIMEOUT_ERROR)
        while (T2CT > END_OF_FRAME);            // let the frame timer run down to the end of a frame

      T2CT = FRAME_TIMEOUT_DEFAULT;       // Reset the Frame Timer
    }     // end of waitingforbeacon 'else' (paired) loop

// Send Data to Master

#ifdef CC1110_LNA_Rev_B
    P2 &= ~0x10;                         // clear P2_4 (Disable LNA)
#endif
#ifdef CC1110_PA_Rev_C
    P2 |= 0x10;                          // set P2_4 (Enable PA)
#endif
    
// Move data from the Codec (audioOut) to the txbuffer    
    
    for (i = 0; i < AF_BUF_SIZE; i++) {
      if (activeOut == 1) {
        SLVtxData.payload[i] = audioOut[1][i];
      }
      else {
        SLVtxData.payload[i] = audioOut[0][i];
      }
    }
  
    rfSendPacket(SLAVE_TX_TIMEOUT_WO_CALIB);

// At this point the LNA (if present) is dissabled    
    
#ifdef CC1110_LNA_Rev_B
    if (rssiavg > RSSI_ENABLE_LNA)       // if RSSI (signal strength) is too low ...
      P2 |= 0x10;                        // set P2_4 (Enable LNA)
#endif
#ifdef CC1110_PA_Rev_C
    P2 &= ~0x10;                         // clear P2_4 (Disable PA)
#endif   

    SIDLE();          // Force the Transceiver into the Idle state
    
// Set the next channel and initiate calibration

    setChannel(HoppingChannels[ActiveChIdx]);     // SetChannel will set the MARCSTATE to IDLE
    ActiveChIdx++;
    if (ActiveChIdx == TOTAL_NUM_CHANNELS)
      ActiveChIdx = 0;
    SCAL();                         // Start PLL calibration at new channel

    if (rxPacketStatus == TIMEOUT_ERROR) {
      LED_RED_REG |= LED_RED;       // light the Red (Paket Lost) LED
 
      for (j = 0; j < AF_BUF_SIZE; j++)     // Mute the audio for the duration of the packet  
        audioIn[activeIn][j] = 0xCF;
      
      lostpkts++;
      if (lostpkts > LOST_PKTS_THR) {       // if LOSTPKTS consecutive packets have been lost
        lostpkts = 0;
        waitingforbeacon = TRUE;    // enter 'waiting for beacon' (resync) mode
      }
    }
    else {                          // A packet was received
      LED_RED_REG &= ~LED_RED;      // extinguish the Red (Paket Lost) LED
      lostpkts = 0;
      
      if (rxPacketStatus == PKT_OK) {               // if a packet was sucessfully received ...

// Transfer audio data from the receive buffer to the audioIn buffer using DMA        
        
        SET_WORD(DmaDesc0.SRCADDRH, DmaDesc0.SRCADDRL, SLVrxData.payload);
        SET_WORD(DmaDesc0.DESTADDRH, DmaDesc0.DESTADDRL, audioIn[activeIn]);
        DmaDesc0.SRCINC = SRCINC_1;                 // Increment Source address 
        DMAARM |= DMA_CHANNEL_0;
        DMAREQ |= DMA_CHANNEL_0;                    // Enable memory-to-memory transfer using DMA channel 0
        while ((DMAARM & DMA_CHANNEL_0) > 0);       // Wait for transfer to complete
      }
      else {
// fill the audioIn buffer with 'nulls' so as to mute the audio
        SET_WORD(DmaDesc0.SRCADDRH, DmaDesc0.SRCADDRL, &audionull);
        SET_WORD(DmaDesc0.DESTADDRH, DmaDesc0.DESTADDRL, audioIn[activeIn]);
        DmaDesc0.SRCINC = SRCINC_0;                 // Do not increment Source address 
        DMAARM |= DMA_CHANNEL_0;
        DMAREQ |= DMA_CHANNEL_0;                    // Enable memory-to-memory transfer using DMA channel 0
        while ((DMAARM & DMA_CHANNEL_0) > 0);       // Wait for transfer to complete
      }
    }     // end of TIMEOUT_ERROR 'else' (i.e., packet received)
  }       // end of 'while (1)' (main program) loop

#endif
}

/***********************************************************************************
  Copyright 2009 Texas Instruments Incorporated. All rights reserved.

  IMPORTANT: Your use of this Software is limited to those specific rights
  granted under the terms of a software license agreement between the user
  who downloaded the software, his/her employer (which must be your employer)
  and Texas Instruments Incorporated (the "License").  You may not use this
  Software unless you agree to abide by the terms of the License. The License
  limits your use, and you acknowledge, that the Software may not be modified,
  copied or distributed unless embedded on a Texas Instruments microcontroller
  or used solely and exclusively in conjunction with a Texas Instruments radio
  frequency transceiver, which is integrated into your product.  Other than for
  the foregoing purpose, you may not use, reproduce, copy, prepare derivative
  works of, modify, distribute, perform, display or sell this Software and/or
  its documentation for any purpose.

  YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE
  PROVIDED �AS IS� WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
  INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE,
  NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL
  TEXAS INSTRUMENTS OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT,
  NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER
  LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
  INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE
  OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT
  OF SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
  (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

  Should you have any questions regarding your right to use this Software,
  contact Texas Instruments Incorporated at www.TI.com.
***********************************************************************************/

