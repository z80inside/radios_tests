 /******************************************************************************************************
 * tw_rf.c                  For use with "CODEC EVM REV B" cards                                       *
 * Compiler:                IAR C Compiler for 8051                                                    *
 * Target platform:         Chipcon CC1110                                                             *
 * Author:                  TBR, KHO, ESY, MJB                                                         *
* Last Update:              02 June 2009                                                               *
 ******************************************************************************************************/

// Includes

#include "twoway.h"
#include "stdlib.h"         // Note: 'stdlib' defines abs as 'int abs(int)'


//-------------------------------------------------------------------------------------------------------
// Global variables

volatile UINT8 __xdata rxPacketStatus;

#ifdef MASTER
TX_MASTER_STRUCT __xdata MAStxData;     // TX packet buffer for data from Master to Slave
RX_MASTER_STRUCT __xdata MASrxData;     // RX packet buffer for data from Slave
#endif

#ifdef SLAVE
TX_SLAVE_STRUCT __xdata SLVtxData;      // TX packet buffer for data from Slave to Master
RX_SLAVE_STRUCT __xdata SLVrxData;      // RX packet buffer for data from Master to Slave
#endif

INT16 __xdata rssi;
INT16 __xdata rssisum = 0;
INT16 __xdata rssiavg = 0;
UINT8 __xdata rssipkts = 0;
UINT8 __xdata rssivalid = 0;            // rssiavg valid when non zero; will remain zero untill 32 packets have been received

//-------------------------------------------------------------------------------------------------------
// Local variables

UINT8 __xdata syncdetected;

////////////////////////////////////////////////////////////////////////////////
/// @brief	Configures the Radio
///
////////////////////////////////////////////////////////////////////////////////

void rfConfigRadio() {

  PKTCTRL1 = 0x04;          // No address check. Append status bytes.
  PKTCTRL0 = 0x45;          // Variable packet length. Use CRC. Enable whitening
  PKTLEN = 0x60;            // Maximum packet length (96 bytes)
  
  // Base Frequency = 914 MHz
  FREQ2 = 0x23;
  FREQ1 = 0x27;
  FREQ0 = 0x62;

#ifdef BAUD250GFSK  
 
  // Filter BW, data rate.
  MDMCFG4 = 0x2D;           // Data Rate = 250 kbps
  MDMCFG3 = 0x3B;           // Rx filter bandwidth = 542 kHz

  // IF frequency
  FSCTRL1 = 0x12;           // IF Frquency = 457 kHz
  FSCTRL0 = 0x00;
    
  // Modulation format, detection level
  MDMCFG2 = 0x13;           // 30/32 bits sync word detection. GFSK modulation.
  MDMCFG1 = 0x43;           // 8 byte preamble. No FEC.
  MDMCFG0 = 0x3B;           // Channel spacing: 250 kHz

  // Deviation setting
  DEVIATN = 0x62;           // Deviation: 127 kHz

#endif
 
#ifdef BAUD300MSK           
  
  // Filter BW, data rate.
  MDMCFG4 = 0x1D;           // Data Rate = 300 kbps
  MDMCFG3 = 0x7A;           // Rx filter bandwidth = 650 kHz

  // IF frequency
  FSCTRL1 = 0x12;           // IF Frquency = 457 kHz
  FSCTRL0 = 0x00;
    
  // Modulation format, detection level
  MDMCFG2 = 0x73;           // 30/32 bits sync word detection. MSK modulation.
  MDMCFG1 = 0x23;           // 4 byte preamble. No FEC.
  MDMCFG0 = 0x3B;           // Channel spacing: 250 kHz

  // Deviation setting
  DEVIATN = 0x00;

#endif
 
  // Calibration synth
  MCSM2 = 0x07;
  MCSM1 = 0x30;             // RXOFF_MOODE: Idle; TXOFF_MODE: Idle
  MCSM0 = 0x08;             // Manual FS calibration

  // Frequency offset compensation configuration
  FOCCFG = 0x1D;

  // Bit synchronization
  BSCFG = 0x1C;

  // AGC settings (from SmartRF04)
  AGCCTRL2 = 0xC7;
  AGCCTRL1 = 0x00;
  AGCCTRL0 = 0xB0;

  // Front end settings (from SmartRF04)
  FREND1 = 0xB6;
  FREND0 = 0x10;

  // Synth calibration
  FSCAL3 = 0xEF;
  FSCAL2 = 0x2C;
  FSCAL1 = 0x24;
  FSCAL0 = 0x1F;
  
  // 'Various Test Settings' (From SmartRF04)
  TEST2 = 0x88;
  TEST1 = 0x31;
  TEST0 = 0x09;  

  // Output power

#ifdef PA
  PA_TABLE0 = 0x84;         // Output power: +5 dBm
#else
  PA_TABLE0 = 0xC0;         // Output power: +10 dBm
#endif

  // Calibrate the frequency synth.
  SIDLE();
  SCAL();
  while(MARCSTATE != MARCSTATE_IDLE);     // Wait for calibration to complete
}

////////////////////////////////////////////////////////////////////////////////
/// @brief	This function initializes the resources necessary for sending
///             and receiving packets
///
/// Two DMA channels are requested from the DMA administrator and set up to transfer
/// data to and from the necessary RX or TX buffers.
/// The radio is configured to transmit at a defined frequency and to
/// automatically calculate and insert a CRC value when in transmit and to
/// check the CRC value in receive.
///
/// @param[in]  frequency
///             The radio base frequency (channel 0) in kHz
///
/// @return
///             Returns TRUE is the configuration is successful and FALSE otherwise
////////////////////////////////////////////////////////////////////////////////
BOOL initRf() {

  rxStatus = RX_IDLE;

  RFIF = 0;                               // Clear RF interrupt flag
  RFIM = 0;                               // Clear RF interrupt enable mask
  INT_SETFLAG(INUM_RF,INT_CLR);           // Clear RF interrupt flag in main interrupt register
  INT_ENABLE(INUM_RF,INT_ON);             // Enable RF interrupts
  rfConfigRadio();                        // Initialize the radio
  IOCFG0 = 0x06;                          // Set GDO0 to Sync Word Status

#ifdef MASTER
  dmaFromRadio(RX_PAYLOAD_LEN + 3, (WORD) &MASrxData);                  // Configure the DMA channel for RX
                                                                        // Include the two bytes appended to the data for status (LQI/RSSI)
  DMA_ABORT_CHANNEL(DMA_RX);                                            // Make sure the DMA channel is disarmed.

  dmaToRadio(TX_PAYLOAD_LEN + 1, (WORD) &MAStxData);                    // Configure the DMA channel for TX
  DMA_ABORT_CHANNEL(DMA_TX);                                            // Make sure the DMA channel is disarmed.
#endif

#ifdef SLAVE
  dmaToRadio(TX_PAYLOAD_LEN + 1, (WORD) &SLVtxData);                    // Configure the DMA channel for transmission. Do not enable DMA interrupt.
  DMA_ABORT_CHANNEL(DMA_TX);                                            // Make sure the DMA channel is disarmed.

  dmaFromRadio(RX_PAYLOAD_LEN + 3, (WORD) &SLVrxData);                  // Configure the DMA channel for RX
  DMA_ABORT_CHANNEL(DMA_RX);                                            // Make sure the DMA channel is disarmed.
#endif

  INT_ENABLE(INUM_DMA, INT_ON);                                         // Enable DMA interrupts
  return TRUE;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief	Transmit the packet that is already in the txData TX buffer
///
/// Arms the TX DMA channel, Starts a TX timeout timer, starts TX mode,
/// waits for the timer to expire, forces the CC2510 to idle if it is still
/// in TX mode when the timer expires.
///
/// The packet to transmit must be in the TX buffer txData before calling this function.
///
/// The timeout should be such that the packet is completely transmitted when
/// the timer expires and TX operates normaly.
///
/// How to calculate timeout:
/// Timeout in milliseconds >= Margin + Calibration time + Total packet length in bytes  * 8 / RF baud rate in kilobits pr second
///
/// The total packet length must include preamble, syncword, header, user data and CRC.
/// Calibration time may be included for simplicity even if calibration is not actually performed.
///
/// @param[in]  none
///
/// @return
///         Returns TRUE is the transmission is successful and FALSE if the transceiver was in TX at timeout
////////////////////////////////////////////////////////////////////////////////

BOOL rfSendPacket(UINT8 timeout, UINT8 multiplier) {
  RFTXRXIF = 0;                                 // clear flag as this serves as a trigger for the DMA
  DMA_ARM_CHANNEL(DMA_TX);

  STX();
  macsetT3TimeoutAndWait(timeout, multiplier);  // wait for normal TX operation to complete
  if(MARCSTATE == MARCSTATE_TX) {
    SIDLE();
    DMA_ABORT_CHANNEL(DMA_TX);                  // Abort the TX DMA channel
    return FALSE;
  }
  if(MARCSTATE != MARCSTATE_IDLE) {
    SIDLE();
    DMA_ABORT_CHANNEL(DMA_TX);                  // Abort the TX DMA channel
    return FALSE;
  }
  return TRUE;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief	Receive a packet
///
/// Tries to receive a packet. Returns either of the following rxPacketStatus:
///             TIMEOUT_ERROR:  If no packet is received within a given time
///             PKT_ERROR:      If either address or length of received packet was incorrect
///             CRC_ERROR:      CRC error in incomming audio data frame
///             PKT_OK:         Received packet is OK
///
/// The timeout will always run out before function returns, so this function should not be used
//  if timeout is longer than RX/2.
///
/// @param[in]  rxData                          Pointer to the received data
///             synctimeout, t3 multiplier      time (in T3 tics) by which SYNC must have been received (GDO0 is checked)
///             timeout                         time (in T2 tics) by which the packet must have been received            
///
////////////////////////////////////////////////////////////////////////////////

#ifdef MASTER
void rfReceivePacket(RX_MASTER_STRUCT __xdata * rxData, UINT8 synctimeout, UINT8 t3_multiplier, BYTE dmaNumber, UINT8 packetlen, UINT8 timeout) {
#else
void rfReceivePacket(RX_SLAVE_STRUCT __xdata * rxData, UINT8 synctimeout, UINT8 t3_multiplier, BYTE dmaNumber, UINT8 packetlen, UINT8 timeout) {
#endif

  rxStatus = RX_WAIT;                                     // Set rxStatus, will be updated if SFD detected
  RFIM = 0x00;                                            // Disable all RF interrupts
  RFIF = 0x00;                                            // Clear all RF interrupts
  INT_SETFLAG(INUM_RF, INT_CLR);                          // Clearing main RF interrupt flags in S1CON[1:0]
  INT_SETFLAG(INUM_DMA, INT_CLR);
  INT_ENABLE(INUM_DMA, INT_ON);                           // Enable DMA interrupt
  RFTXRXIF = 0x00;

  if ( DMAARM != 0x00 )
    DMA_ABORT_CHANNEL(dmaNumber);                         // Abort DMA channel

  DMA_ARM_CHANNEL(dmaNumber);                             // Arm DMA channel
  SRX();                                                  // Strobe RX
  macsetT3TimeoutAndWait(synctimeout, t3_multiplier);     // Start timer
                                                          
  if ((PKTSTATUS & SYNCFND) == 0) {                       // If SYNC was not detected ...
    SIDLE();                                              // Shut down the receiver
    DMA_ABORT_CHANNEL(dmaNumber);                         // Abort DMA channel
    rxPacketStatus = TIMEOUT_ERROR;                       // Return Timeout error
    return;
  }
  else {                                                  // SYNC was detected                         
    while (1) {                                           // Wait until ...
      if ((PKTSTATUS & SYNCFND) == 0)                     // either RX is complete (SYNCFD is false) 
        break;
      if (T2CT <= timeout) {                              // or the timeout period has been exceeded
        SIDLE();                                          // Shut down the receiver
        DMA_ABORT_CHANNEL(dmaNumber);                     // Abort DMA channel
        rxPacketStatus = TIMEOUT_ERROR;                   // Return Timeout error      
        return;
      }
    }
 
    if (rxData->macPayloadLen != packetlen) {
      rxPacketStatus = PKT_ERROR;                         // Return Packet error
    }
    else if (!(rxData->append[CRC_LQI_VAL_IDX] & CRC_OK_MASK)) {
      rxPacketStatus = CRC_ERROR;                         // Return CRC error
    }
    else
      rxPacketStatus = PKT_OK;
      
    if (RSSI >= 128)                                      // calculate RSSI in dBm
      rssi = (int) ((RSSI - 256) >> 1) - RSSI_OFFSET;
    else
      rssi = (int) (RSSI >> 1) - RSSI_OFFSET;
    rssisum += abs(rssi);                                 // convert to asbsolute value
    
    rssipkts++;  
    if (rssipkts > 31) {
      rssipkts = 0;
      rssiavg = rssisum >> 5;                             // calculate the average RSSI value over the last 32 packets
      rssisum = 0;
      rssivalid = 1;                                      // mark rssiavg as valid
    }
    
    return;
  }
}


////////////////////////////////////////////////////////////////////////////////
/// @brief	Listen for Master
///
/// Returns one of the following in rxPacketStatus:
///
///             TIMEOUT_ERROR:  If SYNC was not detected within the timeout period
///             PKT_ERROR:      If either address or length of received packet was incorrect
///             CRC_ERROR:      CRC error in incomming audio data frame
///             PKT_OK:         Received packet is OK
///
/// Unlike 'rfReceivePacket', this routine will return immediately if a packet is received before the 'timeout' period
//
/// @param[in]  rxData
///             Pointer to the received data
///
////////////////////////////////////////////////////////////////////////////////

#ifdef SLAVE

void ListenforMaster(RX_SLAVE_STRUCT __xdata * rxData, UINT8 timeout, UINT8 t3_multiplier, BYTE dmaNumber, UINT8 packetlen) {

  SIDLE();                                                // Force Idle state
  rxStatus = RX_WAIT;                                     // Set rxStatus, will be updated if SFD detected
  RFIM = 0x00;                                            // Disable all RF interrupts
  RFIF = 0x00;                                            // Clear all RF interrupts
  INT_SETFLAG(INUM_RF, INT_CLR);                          // Clearing main RF interrupt flags in S1CON[1:0]
  INT_SETFLAG(INUM_DMA, INT_CLR);
  INT_ENABLE(INUM_DMA, INT_ON);                           // Enable DMA interrupt
  RFTXRXIF = 0x00;

  if ( DMAARM != 0x00 )
    DMA_ABORT_CHANNEL(dmaNumber);                         // Abort DMA channel
  DMA_ARM_CHANNEL(dmaNumber);                             // Arm DMA channel

  syncdetected = 0;
   
  SRX();                                // Strobe RX

  for ( int i = 1; i <= t3_multiplier; i++) {
    TIMER3_RUN(FALSE);                  // Stop Timer
    T3CC0 = timeout;                    // Set timeout period
    TIMER3_RUN(TRUE);                   // Start timer

    while (T3CNT > 0) {          // loop until T3 reaches 0
      if ((PKTSTATUS & SYNCFND) > 0)    // If SYNC has been detected
        syncdetected = 1;
      if ((syncdetected == 1) &&  ((PKTSTATUS & SYNCFND) == 0)) {
// Packet received. Check packet length field and CRC 
        if (rxData->macPayloadLen != packetlen)
          rxPacketStatus = PKT_ERROR;                         // Return Packet error
        else if (!(rxData->append[CRC_LQI_VAL_IDX] & CRC_OK_MASK))
          rxPacketStatus = CRC_ERROR;                         // Return CRC error
        else
          rxPacketStatus = PKT_OK;

        TIMER3_RUN(FALSE);                // Stop timer
        return;
      }         // end of 'sfdDetected' if
    }           // end of 'while' loop - if reached, T3CNT has reached 0
  }             // end of 'for' loop - if reached, SYNC was not detected within timeout period

  rxPacketStatus = TIMEOUT_ERROR;
  return;
}
#endif

////////////////////////////////////////////////////////////////////////////////
/// @brief	Set the T3 timeout and start timer. Counts down twice before returns
////////////////////////////////////////////////////////////////////////////////

void macsetT3TimeoutAndWait(UINT8 timeout, UINT8 multiplier) {

  TIMIF &= ~T3OVFIF;          // Clear RX_TIMEOUT_TIMER_FLAG

  for ( int i = 1; i <= multiplier; i++) {
    T3CC0 = timeout;            // Set timeout period
    TIMER3_RUN(TRUE);           // Start timer

    while(!(TIMIF & T3OVFIF));  // Wait for timeout

    TIMIF &= ~T3OVFIF;          // Clear RX_TIMEOUT_TIMER_FLAG
    TIMER3_RUN(FALSE);          // Stop timer
  }
}


////////////////////////////////////////////////////////////////////////////////
/// @brief	Set next channel after RX/TX completes
////////////////////////////////////////////////////////////////////////////////

void setChannel (UINT8 ch) {
  
  // Only change channel when radio state is IDLE, i.e. not in RX or TX

  while(MARCSTATE != MARCSTATE_IDLE)
    if (MARCSTATE == MARCSTATE_RX_OVERFLOW || MARCSTATE == MARCSTATE_TX_UNDERFLOW || MARCSTATE == MARCSTATE_RX) 
      SIDLE();
  
  CHANNR = ch;
}

/***********************************************************************************
  Copyright 2009 Texas Instruments Incorporated. All rights reserved.

  IMPORTANT: Your use of this Software is limited to those specific rights
  granted under the terms of a software license agreement between the user
  who downloaded the software, his/her employer (which must be your employer)
  and Texas Instruments Incorporated (the "License").  You may not use this
  Software unless you agree to abide by the terms of the License. The License
  limits your use, and you acknowledge, that the Software may not be modified,
  copied or distributed unless embedded on a Texas Instruments microcontroller
  or used solely and exclusively in conjunction with a Texas Instruments radio
  frequency transceiver, which is integrated into your product.  Other than for
  the foregoing purpose, you may not use, reproduce, copy, prepare derivative
  works of, modify, distribute, perform, display or sell this Software and/or
  its documentation for any purpose.

  YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE
  PROVIDED �AS IS� WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
  INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE,
  NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL
  TEXAS INSTRUMENTS OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT,
  NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER
  LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
  INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE
  OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT
  OF SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
  (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

  Should you have any questions regarding your right to use this Software,
  contact Texas Instruments Incorporated at www.TI.com.
***********************************************************************************/
